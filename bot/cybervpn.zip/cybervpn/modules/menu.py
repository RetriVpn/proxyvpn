from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/RetriVpn/proxyvpn/memek/status"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("☠️Ssh Menu☠️", "ssh")],
                    [Button.inline("☠️Vmess Menu☠️", "vmess-member"),
                     Button.inline("☠️Vless Menu☠️", "vless-member")],
                    [Button.inline("☠️Trojan Menu☠️", "trojan-member"),
                     Button.inline("☠️Socks Menu☠️", "shadowsocks-member")],
                    [Button.inline("☠️Noobzv Vpn☠️", "noobzvpn-member")],
                    [Button.url("⭐Tele Group⭐", "https://t.me/retrivpnstore"),
                     Button.inline("📧topup manual📧", f"topup")]
                ]

                member_msg = f"""
**─────────────────**
**     ⚡ RETRI PROJECT ⚡ **
**─────────────────**
**» 🔰Version:** `v3.1.1`
**» 🔰channel:** `@retrivpnstore`
**» 🔰Bot by @RetriVpn **
**» 🔰Your ID ** `{user_id}`
**─────────────────**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("SSH OPENVPN", "ssh")],
                    [Button.inline("VMESS X-RAY", "vmess")],
                    [Button.inline("VLESS X-RAY", "vless")],
                    [Button.inline("TRJAN X-RAY", "trojan")],
                    [Button.inline("SDWSK X-RAY", "shadowsocks")],
                    [Button.inline("NOOBZ VPN-S", "noobzvpns")],
                    [Button.inline("🔰Check Vps Info🔰", "info")],
                    [Button.inline("🔰Other Settings🔰", "setting")],
                    [Button.url("🔰Tele Group🔰", "https://t.me/retrivpnstore")],
                    [Button.url("🔰Order?🔰", "https://t.me/RetriVpn")]
                ]

                admin_msg = f"""
**─────────────────**
**   ⚡ RETRI PROJECT ⚡ **
**─────────────────**
**» 🔰Version:** `v3.1.1`
**» 🔰hannel:** `@retrivpnstore`
**» 🔰Bot by @RetriVpn **
**» 🔰Your ID ** `{user_id}`
**─────────────────**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

